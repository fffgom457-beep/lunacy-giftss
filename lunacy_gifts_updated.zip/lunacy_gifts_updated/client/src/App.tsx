
import { useEffect, useState } from "react";
import { io } from "socket.io-client";

const socket = io("http://localhost:3001");

export default function App() {
  const [multiplier, setMultiplier] =
    useState(1);

  useEffect(() => {
    socket.on("multiplier", (data) => {
      setMultiplier(data.value);
    });
  }, []);

  return (
    <div className="app">
      <div className="logo">
        LUNACY GIFTS
      </div>

      <div className="multiplier">
        x{multiplier.toFixed(2)}
      </div>

      <img
        src="/plane.png"
        className="plane"
      />

      <button className="bet-btn">
        BET
      </button>
    </div>
  );
}
