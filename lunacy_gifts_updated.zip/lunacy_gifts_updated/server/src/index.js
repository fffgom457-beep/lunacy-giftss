
const express = require("express");
const cors = require("cors");
const http = require("http");
const { Server } = require("socket.io");

const app = express();

app.use(cors());

const server =
  http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: "*"
  }
});

let multiplier = 1;

function startCrash() {
  multiplier = 1;

  const crashPoint =
    Math.random() * 10 + 1;

  const interval =
  setInterval(() => {

    multiplier += 0.03;

    io.emit("multiplier", {
      value: multiplier
    });

    if(multiplier >= crashPoint){
      io.emit("crash", {
        value: multiplier
      });

      clearInterval(interval);

      setTimeout(() => {
        startCrash();
      }, 3000);
    }

  }, 50);
}

startCrash();

server.listen(3001, () => {
  console.log(
    "LUNACY GIFTS STARTED"
  );
});
